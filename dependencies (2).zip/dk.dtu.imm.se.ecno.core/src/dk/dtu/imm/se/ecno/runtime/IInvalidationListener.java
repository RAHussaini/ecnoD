package dk.dtu.imm.se.ecno.runtime;

public interface IInvalidationListener {
	
	public void notifyInvalidation(IInvalidationNotifier invalidationNotifier);

}
