package dk.dtu.imm.se.ecno.engine;

import dk.dtu.imm.se.ecno.engine.ExecutionEngine.InvalidChoiceType;
import dk.dtu.imm.se.ecno.runtime.IChoice;
import dk.dtu.imm.se.ecno.runtime.Interaction;

//TODO REV - added for debug purposes. And added to this project to avoid cyclic references.
public interface ECNODebugger {

	public void debug(Interaction interaction);
	public void invalidChoice(IChoice choice, Interaction interaction, InvalidChoiceType type);
}
