package dk.dtu.imm.se.ecno.core;

public interface IReference {

	IElementType getSourceElementType();
	
	IElementType getTargetElementType();

}
