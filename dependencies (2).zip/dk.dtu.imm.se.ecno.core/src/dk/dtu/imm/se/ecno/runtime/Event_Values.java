package dk.dtu.imm.se.ecno.runtime;

import dk.dtu.imm.se.ecno.core.IEventType;

public abstract class Event_Values {
	
	public Event_Values(IEventType type, Event event) {
		super();
	}
	
	public Event_Values super_() {
		return this;
	}

}
