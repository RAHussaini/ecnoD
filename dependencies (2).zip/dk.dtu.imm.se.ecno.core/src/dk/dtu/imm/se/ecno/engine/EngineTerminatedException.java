package dk.dtu.imm.se.ecno.engine;

public class EngineTerminatedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4328050577873624682L;
	

	public EngineTerminatedException(String arg0) {
		super(arg0);
	}

}
