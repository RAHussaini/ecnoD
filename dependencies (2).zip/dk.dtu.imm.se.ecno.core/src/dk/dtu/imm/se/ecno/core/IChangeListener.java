package dk.dtu.imm.se.ecno.core;

public interface IChangeListener {
	
	public void notifyChange(IElementBehaviour elementBehaviour);

}
