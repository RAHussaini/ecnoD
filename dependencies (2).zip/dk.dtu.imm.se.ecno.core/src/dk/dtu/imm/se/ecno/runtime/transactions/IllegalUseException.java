package dk.dtu.imm.se.ecno.runtime.transactions;

public class IllegalUseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1064287135442637604L;

	public IllegalUseException(String arg0) {
		super(arg0);
	}

}
