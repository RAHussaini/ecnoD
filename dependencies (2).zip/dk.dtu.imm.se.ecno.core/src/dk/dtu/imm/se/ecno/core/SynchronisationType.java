package dk.dtu.imm.se.ecno.core;

public enum SynchronisationType {
	
	ONE, ALL

}
