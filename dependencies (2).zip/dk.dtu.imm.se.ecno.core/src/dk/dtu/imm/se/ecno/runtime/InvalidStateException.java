package dk.dtu.imm.se.ecno.runtime;

public class InvalidStateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5064882907814069885L;

}
