package dk.dtu.imm.se.ecno.core;

public interface INamedElement {
	
	public String getName();
	
	public INamespace getNamespace();

}
