package dk.dtu.imm.se.ecno.core;

import java.util.List;

public interface IEventKind extends INamedElement {

	public List<IFormalParameter> getFormalParametersList();
	
}
