/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package dk.dtu.imm.se.ecno.eclipse.save.behaviourstates;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Default Container</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.imm.se.ecno.eclipse.save.behaviourstates.BehaviourstatesPackage#getDefaultContainer()
 * @model
 * @generated
 */
public interface DefaultContainer extends BehaviourState {
} // DefaultContainer
