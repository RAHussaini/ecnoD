/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package dk.dtu.imm.se.ecno.eclipse.save.behaviourstates;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Controller State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.imm.se.ecno.eclipse.save.behaviourstates.BehaviourstatesPackage#getControllerState()
 * @model abstract="true"
 * @generated
 */
public interface ControllerState extends EObject {
} // ControllerState
