/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package dk.dtu.imm.se.ecno.eclipse.save.behaviourstates;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behaviour State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.imm.se.ecno.eclipse.save.behaviourstates.BehaviourstatesPackage#getBehaviourState()
 * @model abstract="true"
 * @generated
 */
public interface BehaviourState extends EObject {

} // BehaviourState
