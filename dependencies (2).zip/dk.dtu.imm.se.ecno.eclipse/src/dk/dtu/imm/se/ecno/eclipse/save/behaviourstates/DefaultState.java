/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package dk.dtu.imm.se.ecno.eclipse.save.behaviourstates;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Default State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dk.dtu.imm.se.ecno.eclipse.save.behaviourstates.BehaviourstatesPackage#getDefaultState()
 * @model
 * @generated
 */
public interface DefaultState extends BehaviourState {
} // DefaultState
